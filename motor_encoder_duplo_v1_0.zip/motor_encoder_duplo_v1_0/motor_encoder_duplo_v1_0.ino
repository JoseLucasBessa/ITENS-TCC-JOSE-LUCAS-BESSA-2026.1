#include <Wire.h>          // I2C Hardware (Sensor 1)
#include <SoftwareWire.h>  // I2C Software (Sensor 2)

// Parâmetros do sistema (Frequências naturais em Hz e amortecimentos)
const float f1 = 0.695;
const float f2 = 1.89;
const float zeta1 = 0.058;
const float zeta2 = 0.054;

// Pinos do Driver do Motor NEMA 17
const int stepPin   = 4;
const int dirPin    = 3;
const int enablePin = 6;

#define AS5600_ADDRESS 0x36
#define RAW_ANGLE_REGISTER 0x0C

SoftwareWire softWire(2, 5); // SDA = D2, SCL = D5

const int TOTAL_PASSOS = 2000;
const unsigned long INTERVALO_PASSO_US     = 1000;  // 1ms por passo (1000 passos/s)
const unsigned long INTERVALO_LEITURA_MS   = 40;   // Amostragem a cada 40ms (25Hz)
const unsigned long TEMPO_POS_MOVIMENTO_MS = 5000; // Grava por 5s após o motor parar

// Variáveis de calibração inicial (atualizadas a cada novo ensaio)
uint16_t zeroOffset1 = 0;
uint16_t zeroOffset2 = 0;

// Seleção do modo de operação: false = Modo Seco (Degrau) | true = Modo Input Shaping ZV
bool usarInputShaping = false; 

// Variáveis internas do Shaper ZV
float amp[4];
int atrasoPassos[4];
int ciclosTotaisZV = 0;

void setup() {
  Serial.begin(9600);

  pinMode(stepPin, OUTPUT);
  pinMode(dirPin, OUTPUT);
  pinMode(enablePin, OUTPUT);

  digitalWrite(enablePin, HIGH); // Motor desabilitado em repouso
  digitalWrite(stepPin, LOW);
  digitalWrite(dirPin, HIGH);

  // Inicializa barramentos I2C na velocidade padrão (100kHz), mais tolerante a cabos longos
  Wire.begin();
  softWire.begin();

  calcularParametrosZV();

  delay(500);
  Serial.println("==================================================");
  Serial.println("SISTEMA PRONTO. Pressione ENTER para iniciar o ensaio...");
  Serial.println("==================================================");
}

void loop() {
  aguardarEnter();

  Serial.println("\n--- INICIANDO NOVO ENSAIO ---");

  // 1. Auto-Calibração do Zero a cada novo ensaio
  zeroOffset1 = readRawAngleHardware();
  zeroOffset2 = readRawAngleSoftware();

  Serial.println("Angulo_Sensor1_Deg,Angulo_Sensor2_Deg,Motor_Ativo");
  delay(100);

  // 2. Habilita o driver e inicia os temporizadores independentes
  digitalWrite(enablePin, LOW);
  delay(10);

  unsigned long ultimoPassoUs   = micros();
  unsigned long ultimaLeituraMs = 0;

  int passosExecutados = 0;
  int cicloAtualZV = 0;
  float acumuladorPassosZV = 0.0;
  
  bool motorEmMovimento = true;
  unsigned long momentoParadaMotorMs = 0;
  bool ensaioFinalizado = false;

  // 3. LOOP DESACOPLADO (Motor e Sensores rodam de forma independente)
  while (!ensaioFinalizado) {
    unsigned long agoraUs = micros();
    unsigned long agoraMs = millis();

    // --- TAREFA A: CONTROLE DO MOTOR ---
    if (motorEmMovimento) {
      if (agoraUs - ultimoPassoUs >= INTERVALO_PASSO_US) {
        ultimoPassoUs = agoraUs;

        if (!usarInputShaping) {
          // MODO SECO (Sem ZV)
          if (passosExecutados < TOTAL_PASSOS) {
            darUmPulso();
            passosExecutados++;
          } else {
            motorEmMovimento = false;
            momentoParadaMotorMs = agoraMs;
            digitalWrite(enablePin, HIGH); // Desliga o motor ao concluir
          }
        } else {
          // MODO INPUT SHAPING ZV
          if (cicloAtualZV < ciclosTotaisZV) {
            float comandoConvoluido = 0.0;
            for (int i = 0; i < 4; i++) {
              int passoRelativo = cicloAtualZV - atrasoPassos[i];
              if (passoRelativo >= 0 && passoRelativo < TOTAL_PASSOS) {
                comandoConvoluido += amp[i];
              }
            }
            acumuladorPassosZV += comandoConvoluido;
            if (acumuladorPassosZV >= 1.0) {
              darUmPulso();
              acumuladorPassosZV -= 1.0;
            }
            cicloAtualZV++;
          } else {
            motorEmMovimento = false;
            momentoParadaMotorMs = agoraMs;
            digitalWrite(enablePin, HIGH); // Desliga o motor ao concluir
          }
        }
      }
    }

    // --- TAREFA B: LEITURA DOS ENCODERS A CADA 100ms ---
    if (agoraMs - ultimaLeituraMs >= INTERVALO_LEITURA_MS) {
      ultimaLeituraMs = agoraMs;
      
      float deg1 = lerGrausIntegrais(readRawAngleHardware(), zeroOffset1);
      float deg2 = lerGrausIntegrais(readRawAngleSoftware(), zeroOffset2);

      Serial.print(deg1, 2);
      Serial.print(",");
      Serial.print(deg2, 2);
      Serial.print(",");
      Serial.println(motorEmMovimento ? 1 : 0);
    }

    // --- CONDIÇÃO DE TÉRMINO DO ENSAIO POR TEMPO FIXO ---
    if (!motorEmMovimento && (agoraMs - momentoParadaMotorMs >= TEMPO_POS_MOVIMENTO_MS)) {
      ensaioFinalizado = true;
      Serial.println("# FIM_DO_ENSAIO");
    }
  }

  Serial.println("Ensaio concluido. Pressione ENTER para repetir...");
}

// --- FUNÇÕES DO MOTOR ---

void darUmPulso() {
  digitalWrite(stepPin, HIGH);
  delayMicroseconds(5);
  digitalWrite(stepPin, LOW);
}

void calcularParametrosZV() {
  float w1 = 2.0 * PI * f1;
  float Td1 = 2.0 * PI / (w1 * sqrt(1.0 - zeta1 * zeta1));
  float K1 = exp(-zeta1 * PI / sqrt(1.0 - zeta1 * zeta1));
  float A1_1 = 1.0 / (1.0 + K1);
  float A1_2 = K1 / (1.0 + K1);
  float t1_2 = Td1 / 2.0;

  float w2 = 2.0 * PI * f2;
  float Td2 = 2.0 * PI / (w2 * sqrt(1.0 - zeta2 * zeta2));
  float K2 = exp(-zeta2 * PI / sqrt(1.0 - zeta2 * zeta2));
  float A2_1 = 1.0 / (1.0 + K2);
  float A2_2 = K2 / (1.0 + K2);
  float t2_2 = Td2 / 2.0;

  float tempo[4];
  amp[0] = A1_1 * A2_1;  tempo[0] = 0;
  amp[1] = A1_1 * A2_2;  tempo[1] = t2_2;
  amp[2] = A1_2 * A2_1;  tempo[2] = t1_2;
  amp[3] = A1_2 * A2_2;  tempo[3] = t1_2 + t2_2;

  for (int i = 0; i < 4; i++) {
    atrasoPassos[i] = round((tempo[i] * 1000000.0) / INTERVALO_PASSO_US);
  }
  ciclosTotaisZV = TOTAL_PASSOS + atrasoPassos[3];
}

// --- FUNÇÕES DOS SENSORES ---

float lerGrausIntegrais(uint16_t rawAngle, uint16_t offset) {
  int16_t calibratedRaw = rawAngle - offset;
  if (calibratedRaw < 0) {
    calibratedRaw += 4096;
  }
  
  float graus = (calibratedRaw * 360.0) / 4096.0;
  
  // Converte a faixa de 180° a 360° para valores negativos (-180° a 0°)
  if (graus > 180.0) {
    graus -= 360.0;
  }
  
  return graus;
}

uint16_t readRawAngleHardware() {
  Wire.beginTransmission(AS5600_ADDRESS);
  Wire.write(RAW_ANGLE_REGISTER);
  if (Wire.endTransmission(false) != 0) return 0;

  Wire.requestFrom(AS5600_ADDRESS, 2);
  if (Wire.available() >= 2) {
    uint8_t highByte = Wire.read();
    uint8_t lowByte  = Wire.read();
    return ((highByte & 0x0F) << 8) | lowByte;
  }
  return 0;
}

uint16_t readRawAngleSoftware() {
  softWire.beginTransmission(AS5600_ADDRESS);
  softWire.write(RAW_ANGLE_REGISTER);
  if (softWire.endTransmission(false) != 0) return 0;

  softWire.requestFrom(AS5600_ADDRESS, 2);
  if (softWire.available() >= 2) {
    uint8_t highByte = softWire.read();
    uint8_t lowByte  = softWire.read();
    return ((highByte & 0x0F) << 8) | lowByte;
  }
  return 0;
}

void aguardarEnter() {
  while (Serial.available() > 0) Serial.read();
  while (Serial.available() == 0) delay(10);
  while (Serial.available() > 0) Serial.read();
}